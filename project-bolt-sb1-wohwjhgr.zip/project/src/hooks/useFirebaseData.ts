import { useState, useEffect } from 'react';
import { Patient, Appointment, MedicalRecord, AIInsight } from '../types';
import {
  subscribeToPatients,
  subscribeToAppointments,
  getMedicalRecords,
  getAIInsights
} from '../services/firebaseService';

export const usePatients = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToPatients((data) => {
      setPatients(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { patients, loading, error };
};

export const useAppointments = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAppointments((data) => {
      setAppointments(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { appointments, loading, error };
};

export const useMedicalRecords = () => {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRecords = async () => {
      try {
        const data = await getMedicalRecords();
        setRecords(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch records');
      } finally {
        setLoading(false);
      }
    };

    fetchRecords();
  }, []);

  return { records, loading, error, refetch: () => {
    setLoading(true);
    getMedicalRecords().then(setRecords).finally(() => setLoading(false));
  }};
};

export const useAIInsights = () => {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchInsights = async () => {
      try {
        const data = await getAIInsights();
        setInsights(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch insights');
      } finally {
        setLoading(false);
      }
    };

    fetchInsights();
  }, []);

  return { insights, loading, error };
};