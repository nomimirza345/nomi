export type UserType = 'jobseeker' | 'company' | 'admin';

export interface JobSeeker {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  skills: string[];
  experience: string;
  education: string;
  resumeUrl?: string;
  profilePicture?: string;
  createdAt: Date;
}

export interface Company {
  id: string;
  name: string;
  email: string;
  phone: string;
  website: string;
  location: string;
  industry: string;
  size: string;
  description: string;
  logo?: string;
  verified: boolean;
  createdAt: Date;
}

export interface Job {
  id: string;
  companyId: string;
  companyName: string;
  companyLogo?: string;
  title: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Internship';
  field: string;
  location: string;
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  experience: string;
  skills: string[];
  benefits: string[];
  status: 'active' | 'closed' | 'draft';
  applicationsCount: number;
  createdAt: Date;
  deadline: Date;
}

export interface Application {
  id: string;
  jobId: string;
  jobTitle: string;
  companyName: string;
  jobSeekerId: string;
  jobSeekerName: string;
  status: 'pending' | 'reviewed' | 'shortlisted' | 'rejected' | 'interview' | 'hired';
  appliedAt: Date;
  coverLetter?: string;
  resumeUrl: string;
  notes?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'application' | 'interview' | 'job_match' | 'system';
  title: string;
  message: string;
  read: boolean;
  createdAt: Date;
  actionUrl?: string;
}

export interface Message {
  id: string;
  fromId: string;
  toId: string;
  fromName: string;
  toName: string;
  subject: string;
  content: string;
  read: boolean;
  createdAt: Date;
  applicationId?: string;
}