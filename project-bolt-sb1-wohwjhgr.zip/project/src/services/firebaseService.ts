import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  Timestamp
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { Patient, Appointment, MedicalRecord, AIInsight, SymptomAnalysis, DrugInteraction } from '../types';

// Patients
export const patientsCollection = collection(db, 'patients');

export const getPatients = async (): Promise<Patient[]> => {
  const snapshot = await getDocs(query(patientsCollection, orderBy('createdAt', 'desc')));
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as Patient[];
};

export const getPatient = async (id: string): Promise<Patient | null> => {
  const docRef = doc(db, 'patients', id);
  const snapshot = await getDoc(docRef);
  if (snapshot.exists()) {
    return {
      id: snapshot.id,
      ...snapshot.data(),
      createdAt: snapshot.data().createdAt?.toDate() || new Date(),
      updatedAt: snapshot.data().updatedAt?.toDate() || new Date()
    } as Patient;
  }
  return null;
};

export const addPatient = async (patient: Omit<Patient, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(patientsCollection, {
    ...patient,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now()
  });
  return docRef.id;
};

export const updatePatient = async (id: string, updates: Partial<Patient>): Promise<void> => {
  const docRef = doc(db, 'patients', id);
  await updateDoc(docRef, {
    ...updates,
    updatedAt: Timestamp.now()
  });
};

export const deletePatient = async (id: string): Promise<void> => {
  const docRef = doc(db, 'patients', id);
  await deleteDoc(docRef);
};

// Appointments
export const appointmentsCollection = collection(db, 'appointments');

export const getAppointments = async (): Promise<Appointment[]> => {
  const snapshot = await getDocs(query(appointmentsCollection, orderBy('date', 'desc')));
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as Appointment[];
};

export const getAppointmentsByDate = async (date: string): Promise<Appointment[]> => {
  const snapshot = await getDocs(
    query(appointmentsCollection, where('date', '==', date), orderBy('time'))
  );
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as Appointment[];
};

export const addAppointment = async (appointment: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(appointmentsCollection, {
    ...appointment,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now()
  });
  return docRef.id;
};

export const updateAppointment = async (id: string, updates: Partial<Appointment>): Promise<void> => {
  const docRef = doc(db, 'appointments', id);
  await updateDoc(docRef, {
    ...updates,
    updatedAt: Timestamp.now()
  });
};

// Medical Records
export const medicalRecordsCollection = collection(db, 'medicalRecords');

export const getMedicalRecords = async (): Promise<MedicalRecord[]> => {
  const snapshot = await getDocs(query(medicalRecordsCollection, orderBy('date', 'desc')));
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as MedicalRecord[];
};

export const getMedicalRecordsByPatient = async (patientId: string): Promise<MedicalRecord[]> => {
  const snapshot = await getDocs(
    query(medicalRecordsCollection, where('patientId', '==', patientId), orderBy('date', 'desc'))
  );
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as MedicalRecord[];
};

export const addMedicalRecord = async (record: Omit<MedicalRecord, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const docRef = await addDoc(medicalRecordsCollection, {
    ...record,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now()
  });
  return docRef.id;
};

// AI Insights
export const aiInsightsCollection = collection(db, 'aiInsights');

export const getAIInsights = async (): Promise<AIInsight[]> => {
  const snapshot = await getDocs(query(aiInsightsCollection, orderBy('createdAt', 'desc'), limit(10)));
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date()
  })) as AIInsight[];
};

export const addAIInsight = async (insight: Omit<AIInsight, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(aiInsightsCollection, {
    ...insight,
    createdAt: Timestamp.now()
  });
  return docRef.id;
};

// Symptom Analysis
export const symptomAnalysisCollection = collection(db, 'symptomAnalysis');

export const addSymptomAnalysis = async (analysis: Omit<SymptomAnalysis, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(symptomAnalysisCollection, {
    ...analysis,
    createdAt: Timestamp.now()
  });
  return docRef.id;
};

export const getSymptomAnalysisByPatient = async (patientId: string): Promise<SymptomAnalysis[]> => {
  const snapshot = await getDocs(
    query(symptomAnalysisCollection, where('patientId', '==', patientId), orderBy('createdAt', 'desc'))
  );
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date()
  })) as SymptomAnalysis[];
};

// Drug Interactions
export const drugInteractionsCollection = collection(db, 'drugInteractions');

export const getDrugInteractions = async (): Promise<DrugInteraction[]> => {
  const snapshot = await getDocs(query(drugInteractionsCollection, orderBy('createdAt', 'desc')));
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date()
  })) as DrugInteraction[];
};

export const addDrugInteraction = async (interaction: Omit<DrugInteraction, 'id' | 'createdAt'>): Promise<string> => {
  const docRef = await addDoc(drugInteractionsCollection, {
    ...interaction,
    createdAt: Timestamp.now()
  });
  return docRef.id;
};

// Real-time listeners
export const subscribeToPatients = (callback: (patients: Patient[]) => void) => {
  return onSnapshot(query(patientsCollection, orderBy('createdAt', 'desc')), (snapshot) => {
    const patients = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      updatedAt: doc.data().updatedAt?.toDate() || new Date()
    })) as Patient[];
    callback(patients);
  });
};

export const subscribeToAppointments = (callback: (appointments: Appointment[]) => void) => {
  return onSnapshot(query(appointmentsCollection, orderBy('date', 'desc')), (snapshot) => {
    const appointments = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      updatedAt: doc.data().updatedAt?.toDate() || new Date()
    })) as Appointment[];
    callback(appointments);
  });
};