import React, { useState } from 'react';
import { UserType } from './types';
import LandingPage from './components/LandingPage';
import UserDashboard from './components/user/UserDashboard';
import CompanyDashboard from './components/company/CompanyDashboard';
import AdminDashboard from './components/admin/AdminDashboard';

function App() {
  const [currentUser, setCurrentUser] = useState<{
    type: UserType | null;
    isAuthenticated: boolean;
    userData?: any;
  }>({
    type: null,
    isAuthenticated: false
  });

  const handleLogin = (userType: UserType, userData: any) => {
    setCurrentUser({
      type: userType,
      isAuthenticated: true,
      userData
    });
  };

  const handleLogout = () => {
    setCurrentUser({
      type: null,
      isAuthenticated: false
    });
  };

  if (!currentUser.isAuthenticated) {
    return <LandingPage onLogin={handleLogin} />;
  }

  switch (currentUser.type) {
    case 'jobseeker':
      return <UserDashboard userData={currentUser.userData} onLogout={handleLogout} />;
    case 'company':
      return <CompanyDashboard userData={currentUser.userData} onLogout={handleLogout} />;
    case 'admin':
      return <AdminDashboard userData={currentUser.userData} onLogout={handleLogout} />;
    default:
      return <LandingPage onLogin={handleLogin} />;
  }
}

export default App;