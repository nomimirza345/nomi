import React, { useState } from 'react';
import { Brain, Send, Lightbulb, AlertTriangle, TrendingUp, Search } from 'lucide-react';

const symptomAnalysis = {
  symptoms: ['Headache', 'Fatigue', 'Fever', 'Nausea'],
  possibleConditions: [
    { condition: 'Migraine', probability: 78, severity: 'moderate' },
    { condition: 'Tension Headache', probability: 65, severity: 'mild' },
    { condition: 'Viral Infection', probability: 45, severity: 'mild' },
    { condition: 'Sinusitis', probability: 32, severity: 'mild' }
  ],
  recommendations: [
    'Consider prescribing migraine-specific medication',
    'Recommend stress management techniques',
    'Schedule follow-up in 2-3 days if symptoms persist',
    'Advise adequate hydration and rest'
  ]
};

const drugInteractions = [
  { drug1: 'Warfarin', drug2: 'Aspirin', risk: 'high', description: 'Increased bleeding risk' },
  { drug1: 'Metformin', drug2: 'Alcohol', risk: 'medium', description: 'Risk of lactic acidosis' },
  { drug1: 'Lisinopril', drug2: 'Ibuprofen', risk: 'medium', description: 'Reduced antihypertensive effect' }
];

export default function AIAssistant() {
  const [activeTab, setActiveTab] = useState<'diagnosis' | 'interactions' | 'chat'>('diagnosis');
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { role: 'assistant', message: 'Hello! I\'m your AI medical assistant. How can I help you today?' }
  ]);

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    
    setChatHistory(prev => [
      ...prev,
      { role: 'user', message: chatMessage },
      { role: 'assistant', message: 'I understand you need assistance with that. Let me analyze the information and provide recommendations based on current medical guidelines.' }
    ]);
    setChatMessage('');
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
            <Brain className="h-8 w-8 text-purple-600" />
            <span>AI Medical Assistant</span>
          </h1>
          <p className="text-gray-600 mt-1">Advanced AI-powered diagnostic support and medical insights</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-600">AI Active</span>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'diagnosis', label: 'Symptom Analysis', icon: Search },
              { id: 'interactions', label: 'Drug Interactions', icon: AlertTriangle },
              { id: 'chat', label: 'AI Chat', icon: Brain }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'diagnosis' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Symptoms Input */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Patient Symptoms</h3>
                  <div className="space-y-2">
                    {symptomAnalysis.symptoms.map((symptom, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <span className="text-gray-900">{symptom}</span>
                        <button className="text-red-600 hover:text-red-700 text-sm">Remove</button>
                      </div>
                    ))}
                  </div>
                  <button className="w-full p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors">
                    + Add Symptom
                  </button>
                </div>

                {/* AI Analysis */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">AI Diagnostic Suggestions</h3>
                  <div className="space-y-3">
                    {symptomAnalysis.possibleConditions.map((condition, index) => (
                      <div key={index} className="p-4 border border-gray-200 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">{condition.condition}</h4>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            condition.severity === 'high' ? 'bg-red-100 text-red-700' :
                            condition.severity === 'moderate' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }`}>
                            {condition.severity}
                          </span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full" 
                              style={{ width: `${condition.probability}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-700">{condition.probability}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5 text-green-600" />
                  <span>AI Recommendations</span>
                </h3>
                <ul className="space-y-2">
                  {symptomAnalysis.recommendations.map((recommendation, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                      <span className="text-gray-700">{recommendation}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'interactions' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Drug Interaction Checker</h3>
                <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                  Check New Interaction
                </button>
              </div>

              <div className="space-y-4">
                {drugInteractions.map((interaction, index) => (
                  <div key={index} className={`p-4 rounded-lg border-l-4 ${
                    interaction.risk === 'high' ? 'bg-red-50 border-red-400' :
                    interaction.risk === 'medium' ? 'bg-yellow-50 border-yellow-400' :
                    'bg-green-50 border-green-400'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className={`h-5 w-5 ${
                          interaction.risk === 'high' ? 'text-red-600' :
                          interaction.risk === 'medium' ? 'text-yellow-600' :
                          'text-green-600'
                        }`} />
                        <span className="font-medium text-gray-900">
                          {interaction.drug1} + {interaction.drug2}
                        </span>
                      </div>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        interaction.risk === 'high' ? 'bg-red-100 text-red-700' :
                        interaction.risk === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {interaction.risk} risk
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{interaction.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4 h-96 overflow-y-auto space-y-4">
                {chatHistory.map((message, index) => (
                  <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.role === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-white border border-gray-200 text-gray-900'
                    }`}>
                      <p className="text-sm">{message.message}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex items-center space-x-4">
                <input
                  type="text"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask the AI assistant anything..."
                  className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
                <button
                  onClick={handleSendMessage}
                  className="bg-purple-600 text-white p-2 rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}