import React, { useState } from 'react';
import { Calendar, Clock, Plus, Filter, CheckCircle, AlertCircle, User, Loader2 } from 'lucide-react';
import { useAppointments, usePatients } from '../hooks/useFirebaseData';
import { addAppointment, updateAppointment } from '../services/firebaseService';
import { Appointment } from '../types';
import AddAppointmentModal from './AddAppointmentModal';

const aiSuggestions = [
  { type: 'optimization', message: 'Consider rescheduling 2:30 PM appointment to reduce waiting time', priority: 'medium' },
  { type: 'reminder', message: '3 patients due for follow-up appointments this week', priority: 'low' },
  { type: 'alert', message: 'Emergency slot available at 3:30 PM today', priority: 'high' }
];

export default function AppointmentScheduling() {
  const { appointments, loading } = useAppointments();
  const { patients } = usePatients();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [filterStatus, setFilterStatus] = useState('All');
  const [showAddAppointment, setShowAddAppointment] = useState(false);

  const filteredAppointments = appointments.filter(appointment => {
    const matchesDate = appointment.date === selectedDate;
    const matchesFilter = filterStatus === 'All' || appointment.status === filterStatus;
    return matchesDate && matchesFilter;
  });

  const handleAddAppointment = async (appointmentData: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      await addAppointment(appointmentData);
      setShowAddAppointment(false);
    } catch (error) {
      console.error('Error adding appointment:', error);
    }
  };

  const handleUpdateAppointment = async (id: string, updates: Partial<Appointment>) => {
    try {
      await updateAppointment(id, updates);
    } catch (error) {
      console.error('Error updating appointment:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700 border-green-200';
      case 'in-progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'waiting': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'urgent': return 'bg-red-100 text-red-700 border-red-200';
      case 'scheduled': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
          <span className="text-gray-600">Loading appointments...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Appointment Scheduling</h1>
          <p className="text-gray-600 mt-1">Manage appointments with AI-powered optimization</p>
        </div>
        <button
          onClick={() => setShowAddAppointment(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Schedule Appointment</span>
        </button>
      </div>

      {/* AI Suggestions */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
          <AlertCircle className="h-5 w-5 text-purple-600" />
          <span>AI Scheduling Suggestions</span>
        </h2>
        <div className="space-y-3">
          {aiSuggestions.map((suggestion, index) => (
            <div key={index} className={`p-3 rounded-lg border ${
              suggestion.priority === 'high' ? 'bg-red-50 border-red-200' :
              suggestion.priority === 'medium' ? 'bg-yellow-50 border-yellow-200' :
              'bg-blue-50 border-blue-200'
            }`}>
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-700">{suggestion.message}</p>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  suggestion.priority === 'high' ? 'bg-red-100 text-red-700' :
                  suggestion.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {suggestion.priority}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Date and Filter Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-gray-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="All">All Status</option>
              <option value="confirmed">Confirmed</option>
              <option value="in-progress">In Progress</option>
              <option value="waiting">Waiting</option>
              <option value="urgent">Urgent</option>
              <option value="scheduled">Scheduled</option>
            </select>
          </div>
        </div>
      </div>

      {/* Appointments Timeline */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">
            Appointments for {new Date(selectedDate).toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </h2>
        </div>
        <div className="p-6">
          {filteredAppointments.length > 0 ? (
            <div className="space-y-4">
              {filteredAppointments.map((appointment) => (
                <div key={appointment.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="font-medium text-gray-900">{appointment.time}</span>
                      </div>
                      <span className={`px-3 py-1 text-xs rounded-full border ${getStatusColor(appointment.status)}`}>
                        {appointment.status.replace('-', ' ')}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">{appointment.duration} min</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{appointment.patientName}</p>
                        <p className="text-sm text-gray-600">Patient</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-emerald-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{appointment.doctorName}</p>
                        <p className="text-sm text-gray-600">Provider</p>
                      </div>
                    </div>
                    
                    <div>
                      <p className="font-medium text-gray-900">{appointment.type}</p>
                      <p className="text-sm text-gray-600">{appointment.notes}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No appointments scheduled</h3>
              <p className="text-gray-600">No appointments found for the selected date and filter.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Appointment Modal */}
      {showAddAppointment && (
        <AddAppointmentModal
          patients={patients}
          onClose={() => setShowAddAppointment(false)}
          onSubmit={handleAddAppointment}
        />
      )}
    </div>
  );
}