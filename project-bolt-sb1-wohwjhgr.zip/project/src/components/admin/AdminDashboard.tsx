import React, { useState } from 'react';
import { Shield, Users, Building2, Briefcase, TrendingUp, AlertTriangle, CheckCircle, X, Eye, Search, Filter, BarChart3, PieChart, Activity, Calendar } from 'lucide-react';

interface AdminDashboardProps {
  userData: any;
  onLogout: () => void;
}

const mockStats = {
  totalUsers: 15420,
  totalCompanies: 1250,
  totalJobs: 3890,
  pendingVerifications: 23,
  flaggedContent: 5,
  monthlyGrowth: 12.5
};

const mockCompanies = [
  { id: '1', name: 'TechCorp Inc.', email: 'hr@techcorp.com', industry: 'Technology', verified: false, joinedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
  { id: '2', name: 'HealthPlus', email: 'jobs@healthplus.com', industry: 'Healthcare', verified: true, joinedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
  { id: '3', name: 'FinanceFlow', email: 'careers@financeflow.com', industry: 'Finance', verified: false, joinedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) }
];

const mockFlaggedJobs = [
  { id: '1', title: 'Suspicious Job Posting', company: 'Unknown Corp', reason: 'Unrealistic salary', reportedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
  { id: '2', title: 'Potential Scam', company: 'Fake Company', reason: 'Requesting personal info', reportedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) }
];

const mockAnalytics = {
  jobsPosted: [
    { month: 'Jan', count: 245 },
    { month: 'Feb', count: 289 },
    { month: 'Mar', count: 356 },
    { month: 'Apr', count: 423 },
    { month: 'May', count: 398 },
    { month: 'Jun', count: 445 }
  ],
  userRegistrations: [
    { month: 'Jan', jobSeekers: 1200, companies: 89 },
    { month: 'Feb', jobSeekers: 1450, companies: 102 },
    { month: 'Mar', jobSeekers: 1680, companies: 125 },
    { month: 'Apr', jobSeekers: 1890, companies: 143 },
    { month: 'May', jobSeekers: 2100, companies: 156 },
    { month: 'Jun', jobSeekers: 2340, companies: 178 }
  ]
};

export default function AdminDashboard({ userData, onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'companies' | 'content' | 'analytics' | 'users'>('overview');
  const [selectedCompany, setSelectedCompany] = useState<any>(null);

  const handleVerifyCompany = (companyId: string) => {
    console.log('Verifying company:', companyId);
  };

  const handleRejectCompany = (companyId: string) => {
    console.log('Rejecting company:', companyId);
  };

  const handleRemoveFlaggedContent = (jobId: string) => {
    console.log('Removing flagged content:', jobId);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-red-600 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">JobConnect</span>
              <span className="text-sm text-gray-500">Admin Panel</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                  <Shield className="h-4 w-4 text-red-600" />
                </div>
                <span className="text-gray-700 font-medium">Admin</span>
                <button
                  onClick={onLogout}
                  className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <nav className="space-y-2">
                {[
                  { id: 'overview', label: 'Overview', icon: TrendingUp },
                  { id: 'companies', label: 'Company Verification', icon: Building2 },
                  { id: 'content', label: 'Content Moderation', icon: AlertTriangle },
                  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
                  { id: 'users', label: 'User Management', icon: Users }
                ].map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id as any)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === item.id
                          ? 'bg-red-50 text-red-700 border border-red-200'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <Users className="h-6 w-6 text-blue-600" />
                      </div>
                      <span className="text-green-600 text-sm font-medium">+{mockStats.monthlyGrowth}%</span>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900 mb-1">{mockStats.totalUsers.toLocaleString()}</p>
                      <p className="text-gray-600 text-sm">Total Users</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-emerald-100 p-3 rounded-lg">
                        <Building2 className="h-6 w-6 text-emerald-600" />
                      </div>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900 mb-1">{mockStats.totalCompanies.toLocaleString()}</p>
                      <p className="text-gray-600 text-sm">Registered Companies</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-purple-100 p-3 rounded-lg">
                        <Briefcase className="h-6 w-6 text-purple-600" />
                      </div>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900 mb-1">{mockStats.totalJobs.toLocaleString()}</p>
                      <p className="text-gray-600 text-sm">Active Job Postings</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-yellow-100 p-3 rounded-lg">
                        <AlertTriangle className="h-6 w-6 text-yellow-600" />
                      </div>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900 mb-1">{mockStats.pendingVerifications}</p>
                      <p className="text-gray-600 text-sm">Pending Verifications</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="bg-red-100 p-3 rounded-lg">
                        <AlertTriangle className="h-6 w-6 text-red-600" />
                      </div>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-gray-900 mb-1">{mockStats.flaggedContent}</p>
                      <p className="text-gray-600 text-sm">Flagged Content</p>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                    <div className="p-6 border-b border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900">Recent Company Registrations</h3>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {mockCompanies.slice(0, 3).map(company => (
                          <div key={company.id} className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <Building2 className="h-5 w-5 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{company.name}</p>
                                <p className="text-sm text-gray-600">{company.industry}</p>
                              </div>
                            </div>
                            <span className={`px-2 py-1 text-xs rounded-full ${
                              company.verified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                            }`}>
                              {company.verified ? 'Verified' : 'Pending'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                    <div className="p-6 border-b border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900">Flagged Content</h3>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {mockFlaggedJobs.map(job => (
                          <div key={job.id} className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-gray-900">{job.title}</p>
                              <p className="text-sm text-gray-600">{job.reason}</p>
                            </div>
                            <button className="text-red-600 hover:text-red-700 text-sm font-medium">
                              Review
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'companies' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Company Verification</h2>
                  <div className="flex space-x-3">
                    <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent">
                      <option value="all">All Companies</option>
                      <option value="pending">Pending Verification</option>
                      <option value="verified">Verified</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Company</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Industry</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Joined Date</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {mockCompanies.map(company => (
                          <tr key={company.id} className="hover:bg-gray-50 transition-colors">
                            <td className="py-4 px-6">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                  <Building2 className="h-5 w-5 text-blue-600" />
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900">{company.name}</p>
                                  <p className="text-sm text-gray-600">{company.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-6">
                              <p className="text-gray-900">{company.industry}</p>
                            </td>
                            <td className="py-4 px-6">
                              <p className="text-gray-600">{company.joinedAt.toLocaleDateString()}</p>
                            </td>
                            <td className="py-4 px-6">
                              <span className={`px-3 py-1 text-xs rounded-full ${
                                company.verified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                              }`}>
                                {company.verified ? 'Verified' : 'Pending'}
                              </span>
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => setSelectedCompany(company)}
                                  className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                >
                                  <Eye className="h-4 w-4" />
                                </button>
                                {!company.verified && (
                                  <>
                                    <button
                                      onClick={() => handleVerifyCompany(company.id)}
                                      className="p-2 text-gray-600 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                                    >
                                      <CheckCircle className="h-4 w-4" />
                                    </button>
                                    <button
                                      onClick={() => handleRejectCompany(company.id)}
                                      className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                    >
                                      <X className="h-4 w-4" />
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'content' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Content Moderation</h2>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900">Flagged Job Postings</h3>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {mockFlaggedJobs.map(job => (
                        <div key={job.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h4 className="font-medium text-gray-900">{job.title}</h4>
                              <p className="text-gray-600">{job.company}</p>
                              <p className="text-sm text-red-600 mt-1">Reason: {job.reason}</p>
                            </div>
                            <span className="text-xs text-gray-500">
                              Reported {job.reportedAt.toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex space-x-3">
                            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                              Review Details
                            </button>
                            <button
                              onClick={() => handleRemoveFlaggedContent(job.id)}
                              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
                            >
                              Remove Content
                            </button>
                            <button className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm">
                              Mark as Safe
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Platform Analytics</h2>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Job Postings</h3>
                    <div className="space-y-3">
                      {mockAnalytics.jobsPosted.map(data => (
                        <div key={data.month} className="flex items-center justify-between">
                          <span className="text-gray-600">{data.month}</span>
                          <div className="flex items-center space-x-3">
                            <div className="w-32 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${(data.count / 500) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-gray-900 font-medium">{data.count}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">User Registrations</h3>
                    <div className="space-y-3">
                      {mockAnalytics.userRegistrations.map(data => (
                        <div key={data.month} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">{data.month}</span>
                            <span className="text-gray-900 font-medium">
                              {data.jobSeekers + data.companies} total
                            </span>
                          </div>
                          <div className="flex space-x-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-green-600 h-2 rounded-full" 
                                style={{ width: `${(data.jobSeekers / 2500) * 100}%` }}
                              ></div>
                            </div>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${(data.companies / 200) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="flex justify-between text-xs text-gray-500">
                            <span>{data.jobSeekers} job seekers</span>
                            <span>{data.companies} companies</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">User Management</h2>
                  <div className="flex space-x-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search users..."
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                      />
                    </div>
                    <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent">
                      <option value="all">All Users</option>
                      <option value="jobseekers">Job Seekers</option>
                      <option value="companies">Companies</option>
                      <option value="active">Active</option>
                      <option value="suspended">Suspended</option>
                    </select>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                  <div className="p-6">
                    <div className="text-center py-12">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">User Management</h3>
                      <p className="text-gray-600">Advanced user management features coming soon.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Company Details Modal */}
      {selectedCompany && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6  border-b border-gray-200">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedCompany.name}</h2>
                  <p className="text-gray-600">{selectedCompany.email}</p>
                </div>
                <button
                  onClick={() => setSelectedCompany(null)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Industry</h3>
                <p className="text-gray-700">{selectedCompany.industry}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Registration Date</h3>
                <p className="text-gray-700">{selectedCompany.joinedAt.toLocaleDateString()}</p>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Verification Status</h3>
                <span className={`px-3 py-1 text-sm rounded-full ${
                  selectedCompany.verified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {selectedCompany.verified ? 'Verified' : 'Pending Verification'}
                </span>
              </div>
              
              {!selectedCompany.verified && (
                <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                  <button
                    onClick={() => handleRejectCompany(selectedCompany.id)}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    Reject
                  </button>
                  <button
                    onClick={() => handleVerifyCompany(selectedCompany.id)}
                    className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Verify Company
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}