import React, { useState } from 'react';
import { Plus, Users, Eye, MessageSquare, Settings, LogOut, Building2, Briefcase, Calendar, TrendingUp, Search, Filter, Edit, Trash2, Star, MapPin, Clock, DollarSign } from 'lucide-react';
import { Job, Application } from '../../types';

interface CompanyDashboardProps {
  userData: any;
  onLogout: () => void;
}

const mockJobs: Job[] = [
  {
    id: '1',
    companyId: 'comp1',
    companyName: 'TechCorp Inc.',
    title: 'Senior Frontend Developer',
    description: 'We are looking for an experienced frontend developer to join our team and help build amazing user experiences.',
    requirements: ['React', 'TypeScript', '3+ years experience', 'Problem-solving skills'],
    responsibilities: ['Develop user interfaces', 'Collaborate with design team', 'Code reviews', 'Mentoring junior developers'],
    type: 'Full-time',
    field: 'Technology',
    location: 'San Francisco, CA',
    salary: { min: 80000, max: 120000, currency: 'USD' },
    experience: '3-5 years',
    skills: ['React', 'TypeScript', 'CSS', 'JavaScript'],
    benefits: ['Health Insurance', 'Remote Work', '401k', 'Stock Options'],
    status: 'active',
    applicationsCount: 45,
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  },
  {
    id: '2',
    companyId: 'comp1',
    companyName: 'TechCorp Inc.',
    title: 'Backend Developer',
    description: 'Join our backend team to build scalable and robust server-side applications.',
    requirements: ['Node.js', 'Python', '2+ years experience', 'Database knowledge'],
    responsibilities: ['API development', 'Database design', 'System architecture', 'Performance optimization'],
    type: 'Full-time',
    field: 'Technology',
    location: 'Remote',
    salary: { min: 70000, max: 100000, currency: 'USD' },
    experience: '2-4 years',
    skills: ['Node.js', 'Python', 'MongoDB', 'PostgreSQL'],
    benefits: ['Health Insurance', 'Flexible Hours', 'Learning Budget'],
    status: 'active',
    applicationsCount: 23,
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    deadline: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000)
  }
];

const mockApplications: Application[] = [
  {
    id: '1',
    jobId: '1',
    jobTitle: 'Senior Frontend Developer',
    companyName: 'TechCorp Inc.',
    jobSeekerId: 'user1',
    jobSeekerName: 'John Doe',
    status: 'pending',
    appliedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    resumeUrl: '/resume.pdf',
    coverLetter: 'I am very interested in this position...'
  },
  {
    id: '2',
    jobId: '1',
    jobTitle: 'Senior Frontend Developer',
    companyName: 'TechCorp Inc.',
    jobSeekerId: 'user2',
    jobSeekerName: 'Jane Smith',
    status: 'reviewed',
    appliedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    resumeUrl: '/resume2.pdf'
  },
  {
    id: '3',
    jobId: '2',
    jobTitle: 'Backend Developer',
    companyName: 'TechCorp Inc.',
    jobSeekerId: 'user3',
    jobSeekerName: 'Mike Johnson',
    status: 'shortlisted',
    appliedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    resumeUrl: '/resume3.pdf'
  }
];

export default function CompanyDashboard({ userData, onLogout }: CompanyDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'jobs' | 'applicants' | 'messages' | 'profile'>('overview');
  const [showJobModal, setShowJobModal] = useState(false);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);

  const stats = [
    { label: 'Active Jobs', value: mockJobs.filter(j => j.status === 'active').length, icon: Briefcase, color: 'bg-blue-500' },
    { label: 'Total Applications', value: mockApplications.length, icon: Users, color: 'bg-green-500' },
    { label: 'Interviews Scheduled', value: mockApplications.filter(a => a.status === 'interview').length, icon: Calendar, color: 'bg-purple-500' },
    { label: 'Hired This Month', value: mockApplications.filter(a => a.status === 'hired').length, icon: TrendingUp, color: 'bg-emerald-500' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'reviewed': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'shortlisted': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'interview': return 'bg-green-100 text-green-700 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
      case 'hired': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const handleStatusChange = (applicationId: string, newStatus: string) => {
    // Handle status change
    console.log('Changing status:', applicationId, newStatus);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Building2 className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-900">JobConnect</span>
              <span className="text-sm text-gray-500">for Employers</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold text-sm">
                    {userData.name?.split(' ').map((n: string) => n[0]).join('') || 'C'}
                  </span>
                </div>
                <span className="text-gray-700 font-medium">{userData.name}</span>
                {!userData.verified && (
                  <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">
                    Pending Verification
                  </span>
                )}
                <button
                  onClick={onLogout}
                  className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <nav className="space-y-2">
                {[
                  { id: 'overview', label: 'Overview', icon: TrendingUp },
                  { id: 'jobs', label: 'Job Postings', icon: Briefcase },
                  { id: 'applicants', label: 'Applicants', icon: Users },
                  { id: 'messages', label: 'Messages', icon: MessageSquare },
                  { id: 'profile', label: 'Company Profile', icon: Building2 }
                ].map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id as any)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === item.id
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {stats.map((stat) => {
                    const Icon = stat.icon;
                    return (
                      <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className={`${stat.color} p-3 rounded-lg`}>
                            <Icon className="h-6 w-6 text-white" />
                          </div>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</p>
                          <p className="text-gray-600 text-sm">{stat.label}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Recent Applications */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-xl font-semibold text-gray-900">Recent Applications</h2>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {mockApplications.slice(0, 5).map(application => (
                        <div key={application.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 font-medium text-sm">
                                {application.jobSeekerName.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{application.jobSeekerName}</p>
                              <p className="text-sm text-gray-600">{application.jobTitle}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className={`px-3 py-1 text-xs rounded-full border ${getStatusColor(application.status)}`}>
                              {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                            </span>
                            <button
                              onClick={() => setSelectedApplication(application)}
                              className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                            >
                              View
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'jobs' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Job Postings</h2>
                  <button
                    onClick={() => setShowJobModal(true)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Post New Job</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {mockJobs.map(job => (
                    <div key={job.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900 mb-2">{job.title}</h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <MapPin className="h-4 w-4" />
                              <span>{job.location}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Clock className="h-4 w-4" />
                              <span>{job.type}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <DollarSign className="h-4 w-4" />
                              <span>${job.salary.min.toLocaleString()} - ${job.salary.max.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-3 py-1 text-xs rounded-full ${
                            job.status === 'active' ? 'bg-green-100 text-green-700' :
                            job.status === 'closed' ? 'bg-red-100 text-red-700' :
                            'bg-yellow-100 text-yellow-700'
                          }`}>
                            {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                          </span>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-4 line-clamp-2">{job.description}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>{job.applicationsCount} applications</span>
                          <span>Posted {Math.floor((Date.now() - job.createdAt.getTime()) / (1000 * 60 * 60 * 24))} days ago</span>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setSelectedJob(job)}
                            className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button className="p-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
                            <Edit className="h-4 w-4" />
                          </button>
                          <button className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'applicants' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Applicants</h2>
                  <div className="flex space-x-3">
                    <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                      <option value="all">All Jobs</option>
                      {mockJobs.map(job => (
                        <option key={job.id} value={job.id}>{job.title}</option>
                      ))}
                    </select>
                    <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                      <option value="all">All Status</option>
                      <option value="pending">Pending</option>
                      <option value="reviewed">Reviewed</option>
                      <option value="shortlisted">Shortlisted</option>
                      <option value="interview">Interview</option>
                      <option value="hired">Hired</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Candidate</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Job Position</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Applied Date</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Status</th>
                          <th className="text-left py-4 px-6 font-medium text-gray-900">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {mockApplications.map(application => (
                          <tr key={application.id} className="hover:bg-gray-50 transition-colors">
                            <td className="py-4 px-6">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                  <span className="text-blue-600 font-medium text-sm">
                                    {application.jobSeekerName.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900">{application.jobSeekerName}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-6">
                              <p className="text-gray-900">{application.jobTitle}</p>
                            </td>
                            <td className="py-4 px-6">
                              <p className="text-gray-600">{application.appliedAt.toLocaleDateString()}</p>
                            </td>
                            <td className="py-4 px-6">
                              <select
                                value={application.status}
                                onChange={(e) => handleStatusChange(application.id, e.target.value)}
                                className={`px-3 py-1 text-xs rounded-full border ${getStatusColor(application.status)} bg-transparent`}
                              >
                                <option value="pending">Pending</option>
                                <option value="reviewed">Reviewed</option>
                                <option value="shortlisted">Shortlisted</option>
                                <option value="interview">Interview</option>
                                <option value="hired">Hired</option>
                                <option value="rejected">Rejected</option>
                              </select>
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => setSelectedApplication(application)}
                                  className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                >
                                  <Eye className="h-4 w-4" />
                                </button>
                                <button className="p-2 text-gray-600 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                                  <MessageSquare className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-xl font-semibold text-gray-900">Company Profile</h2>
                </div>
                <div className="p-6 space-y-6">
                  <div className="flex items-center space-x-6">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center">
                      <Building2 className="h-10 w-10 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{userData.name}</h3>
                      <p className="text-gray-600">{userData.industry}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        {userData.verified ? (
                          <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                            Verified Company
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">
                            Pending Verification
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Company Email</label>
                      <input
                        type="email"
                        value={userData.email || ''}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Website</label>
                      <input
                        type="url"
                        value={userData.website || ''}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
                      <select
                        value={userData.industry || ''}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select industry</option>
                        <option value="Technology">Technology</option>
                        <option value="Healthcare">Healthcare</option>
                        <option value="Finance">Finance</option>
                        <option value="Education">Education</option>
                        <option value="Manufacturing">Manufacturing</option>
                        <option value="Retail">Retail</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Company Size</label>
                      <select
                        value={userData.size || ''}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select size</option>
                        <option value="1-10">1-10 employees</option>
                        <option value="11-50">11-50 employees</option>
                        <option value="51-200">51-200 employees</option>
                        <option value="201-500">201-500 employees</option>
                        <option value="500+">500+ employees</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Company Description</label>
                    <textarea
                      value={userData.description || ''}
                      rows={4}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Tell us about your company..."
                    />
                  </div>

                  <div className="flex justify-end">
                    <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'messages' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-xl font-semibold text-gray-900">Messages</h2>
                </div>
                <div className="p-6">
                  <div className="text-center py-12">
                    <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No messages</h3>
                    <p className="text-gray-600">Messages with candidates will appear here.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Application Details Modal */}
      {selectedApplication && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{selectedApplication.jobSeekerName}</h2>
                  <p className="text-gray-600">{selectedApplication.jobTitle}</p>
                </div>
                <button
                  onClick={() => setSelectedApplication(null)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Application Status</h3>
                <span className={`px-3 py-1 text-sm rounded-full border ${getStatusColor(selectedApplication.status)}`}>
                  {selectedApplication.status.charAt(0).toUpperCase() + selectedApplication.status.slice(1)}
                </span>
              </div>
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Applied Date</h3>
                <p className="text-gray-700">{selectedApplication.appliedAt.toLocaleDateString()}</p>
              </div>
              
              {selectedApplication.coverLetter && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Cover Letter</h3>
                  <p className="text-gray-700">{selectedApplication.coverLetter}</p>
                </div>
              )}
              
              <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  View Resume
                </button>
                <div className="flex space-x-3">
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                    Schedule Interview
                  </button>
                  <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                    Reject
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}