import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAGAlh0bLK_lCLqC-Uy6Gm-4rd7BqLD2ak",
  authDomain: "medflow-emr.firebaseapp.com",
  projectId: "medflow-emr",
  storageBucket: "medflow-emr.firebasestorage.app",
  messagingSenderId: "277233849744",
  appId: "1:277233849744:web:8d0c92a4a42bcf1e2ecf15",
  measurementId: "G-2QKFJ842XN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export default app;